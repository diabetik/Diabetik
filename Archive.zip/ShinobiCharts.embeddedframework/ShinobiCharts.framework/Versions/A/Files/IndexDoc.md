ShinobiCharts is a  set of powerful and flexible chart control for iOS, created
by [ShinobiControls](http://www.shinobicontrols.com/). 

We highly recommend taking a look at our ChartsUserGuide document.

## API Reference